import bpy
from . import placement_report
from .placement import effective_zone
from .constants import FBX_DEFAULTS
from .journal import STATE_AFTER, STATE_BEFORE, map_state
from .ui_common import collection_prop, draw_zone_banner, paths_entry, shown_zone

MAX_ISSUE_ROWS = 5


class MRT_PT_Export(bpy.types.Panel):
    bl_label = 'Export'
    bl_idname = 'MRT_PT_export'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Map Roundtrip'

    def draw(self, context):
        p = context.scene.mrt_props
        layout = self.layout
        layout.operator_context = 'INVOKE_DEFAULT'
        draw_zone_banner(layout, context, 'Export panel: FBX of the selected meshes. The CSV of {zone} is in Zones.')
        col = layout.column()
        col.enabled = not p.running
        box = col.box()
        box.label(text='Paths')
        box.prop(p, 'exchange_dir')
        box.label(text='Reference only; set actual file paths separately.', icon='INFO')
        box.prop(p, 'zone_name')
        box.label(text='Zone selection and CSV: use the Zones panel above.')
        box = col.box()
        box.label(text='FBX Export')
        box.label(text=f'Selected Meshes  {sum(ob.type == "MESH" for ob in context.selected_objects)}')
        box.operator('mrt.export_fbx_native', icon='EXPORT')
        box.label(text='Settings and presets open in Blender file browser.')
        col.prop(p, 'show_batch_export', icon='TRIA_DOWN' if p.show_batch_export else 'TRIA_RIGHT', emboss=False)
        if p.show_batch_export:
            box = col.box()
            box.label(text='FBX Export')
            box.prop(p, 'fbx_preset')
            row = box.row(align=True)
            row.operator('mrt.save_preset', text='', icon='ADD')
            row.operator('mrt.delete_preset', text='', icon='X')
            box.label(text=f'Selected Meshes  {sum(ob.type == "MESH" for ob in context.selected_objects)}')
            box.prop(p, 'fbx_files', expand=True)
            box.prop(p, 'fbx_out_dir')
            box = col.box()
            box.label(text='Advanced')
            for key in FBX_DEFAULTS:
                if key == 'fbx_axis_forward':
                    row = box.row(align=True)
                    row.prop(p, key)
                    row.prop(p, 'fbx_axis_up')
                elif key != 'fbx_axis_up':
                    box.prop(p, key)
            col.operator('mrt.export_fbx')
            col.label(text='Last export: ' + p.last_export)
        if p.status:
            layout.label(text=p.status)
        if p.running:
            layout.progress(factor=p.progress, type='BAR', text='Working | ESC cancels')


class MRT_PT_Import(bpy.types.Panel):
    bl_label = 'Import'
    bl_idname = 'MRT_PT_import'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Map Roundtrip'

    def draw(self, context):
        p = context.scene.mrt_props
        layout = self.layout
        layout.operator_context = 'INVOKE_DEFAULT'
        layout.enabled = not p.running
        zone = draw_zone_banner(layout, context, 'Import: archive the original objects of {zone}, then place every CSV row into it.')
        box = layout.box()
        box.label(text='Zone to import into')
        box.prop(p, 'zone_choice', text='Zone')  # the same Zone as in the Zones panel
        if zone in ('', 'ALL'):
            row = box.row()
            row.alert = True
            row.label(text='Choose one zone (All Zones cannot be imported).', icon='ERROR')
        box = layout.box()
        box.label(text='Collections')
        for name in ('library_coll', 'map_coll', 'new_mesh_coll', 'archive_coll'):
            collection_prop(box, p, name)
        box.label(text='New meshes go to New Meshes To (default: below Library).')
        box.label(text='The original objects go to _Replaced_<Zone> in Archive To (default: scene root).')
        box = layout.box()
        box.label(text='Return Files')
        box.label(text='Return Folder is a reference, not an automatic import.')
        box.prop(p, 'return_dir')
        if zone in ('', 'ALL'):
            box.label(text='Choose a zone: the CSV and FBX paths are saved per zone.', icon='INFO')
        else:
            entry = paths_entry(p, zone)
            if entry is None:
                box.label(text=f'Preparing the paths of {zone}...')
            else:
                box.prop(entry, 'csv_path')
                box.prop(entry, 'fbx_path')
                box.label(text=f'The CSV and FBX paths above belong to {zone}.', icon='INFO')
        for name in ('convert_houdini_fbx', 'name_mode', 'if_exists'):
            box.prop(p, name)
        box = layout.box()
        box.label(text=f'Import into {zone}' if zone not in ('', 'ALL') else 'Import')
        box.prop(p, 'dry_run')
        box.prop(p, 'skip_bad_rows')
        row = box.row()
        row.enabled = zone not in ('', 'ALL')
        row.operator('mrt.import_meshes')
        row.operator('mrt.swap_meshes', text='Swap Meshes' if not p.dry_run else 'Preview Swap')
        state = map_state(zone) if zone not in ('', 'ALL') else ''
        row = box.row()
        row.enabled = zone not in ('', 'ALL')
        row.operator('mrt.replace_zone', text='Preview Import' if p.dry_run else 'Import Zone')
        if state:
            showing_imported = state == STATE_AFTER
            op = box.operator('mrt.switch_map_state', text='Restore Original Map' if showing_imported else 'Re-apply Imported Map')
            op.target = 'BEFORE' if showing_imported else 'AFTER'
            op.zone = zone
        plan = box.box()
        if p.plan_ready:
            plan.label(text=f'Plan for {p.plan_zone}:')
            plan.label(text=f'Archive {p.plan_archive} original objects to _Replaced_{p.plan_zone}')
            plan.label(text=f'Delete {p.plan_delete} objects from the earlier import')
            plan.label(text=f'Place {p.plan_create} CSV rows (use 0: {p.plan_unused_rows} rows); new collections {p.plan_collections}')
            if p.plan_invalid or p.plan_missing:
                row = plan.row()
                row.alert = True
                row.label(text=f'Cannot place: {p.plan_invalid} unreadable rows, {p.plan_missing_rows} rows without a Library mesh')
            if p.plan_missing:
                row = plan.row()
                row.alert = True
                row.label(text=f'{p.plan_missing} names not found in Library: {p.plan_names}')
            if p.plan_block:
                row = plan.row()
                row.alert = True
                row.label(text='Import is blocked:', icon='ERROR')
                for start in range(0, len(p.plan_block), 100):
                    plan.label(text=p.plan_block[start:start + 100])
            if p.plan_errors or p.plan_warnings:
                row = plan.row()
                row.alert = bool(p.plan_errors)
                row.label(text=f'{p.plan_errors} errors (row not used), {p.plan_warnings} warnings')
                for message in placement_report.first_lines(placement_report.LAST_ISSUES, MAX_ISSUE_ROWS):
                    plan.label(text=message if len(message) <= 110 else message[:107] + '...')
                plan.label(text=f'Full list: Text "{placement_report.REPORT_TEXT}"')
        else:
            plan.label(text='Run Preview Import to see the plan.')
        plan.label(text=f'Imported {p.plan_new_meshes_imported} meshes this session' if p.plan_new_meshes_imported else 'No meshes imported yet')
        if p.status:
            layout.label(text=p.status)
        if p.running:
            layout.progress(factor=p.progress, type='BAR', text='Working | ESC cancels')
