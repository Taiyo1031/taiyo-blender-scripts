# Taiyo Object Groups 1.1.2 — 検証結果

2026-10-27 / macOS arm64。200共有Mesh Object（65個以上の一括適用経路）で、元Objectと描画用評価済みObjectの両方を比較。

| 試験 | 4.5.9 | 5.2.2 |
|---|---|---|
| Group Colors ON・色変更・OFFで元色復元 | PASS | PASS |
| 一括色適用後Cancelで描画色復元 | PASS | PASS |
| 一括Viewport制限と解除の評価済み状態・visible_get | PASS | PASS |
| Render制限と解除の評価済み状態 | PASS | PASS |

修正前は元色が赤でも評価済みObjectは白のままで、修正後は一致することを確認。Blender 4.5.10実機 / Windows / Linux / ユーザーの制作SceneはNOT RUN。
テストは `tools/test_zone_groups_display_sync.py`。機械可読結果は `tools/reference/zone_groups/results/1.1.2/`。

6万共有Mesh Objectの4.5.9実UI回帰: Isolate 3.73秒・解除2.63秒、Cancel要求後の復元6.72秒、Undo/Redo PASS。最大処理区間は 131.17ms。5.2.2での6万Object再測定はNOT RUN。

---
以下は1.1.1以前の履歴結果です。

# Taiyo Object Groups 1.1.1 — 検証結果

検証日: 2026-10-27。macOS / arm64。6万ObjectのIsolate不具合を修正。

| 実UI試験（6万共有Mesh Object） | 4.5.9 LTS | 5.2.2 LTS |
|---|---:|---:|
| Isolate完了・結果一致 | PASS / 3.52秒 | PASS / 4.74秒 |
| Show All・元monitor/eye/lock復元 | PASS / 3.49秒 | PASS / 4.43秒 |
| 一括適用後Cancelの全状態復元 | PASS | PASS |
| ネイティブUndo/Redo | PASS | PASS |
| 全試験の最大処理区間 | 108.32ms | 73.18ms |
| 表示一括APIの最大区間 | 5.99ms | 6.68ms |

4.5.9のCancel復元は要求後5.76秒。5.2.2のCancel試験は開始から復元完了まで12.22秒（Cancel要求後だけの時間はNOT RUN）。初期Scene作成とUndoスナップショット等も含むため、最大区間は5ms保証ではありません。

旧方式の再現: 6千Emptyで16.72秒。表示読取りを分離するだけでも6万Objectでは90秒で486件に留まりました。一括適用後は6万Emptyを4.50秒で完了。

既存Background統合テストは両バージョンPASS（制限・元色・Scene共有競合・Cancel）。5.2.2の全操作ファミリー実UI Undo/RedoとMesh Live/CancelもPASS。Windows/Linux、ユーザーの実制作Scene、巨大なMesh形状の再負荷試験はNOT RUN。

原本結果: `tools/reference/zone_groups/results/1.1.1/`。再現スクリプト: `tools/ui_test_zone_groups_isolate_large.py`。

---
以下は1.1.0の履歴結果です。

# Taiyo Object Groups 1.1.0 — 検証結果

検証日: 2026-10-27。macOS / arm64。Blender 4.5.9 LTS / 5.2.2 LTS。
Windows・Linuxは **NOT RUN**。以下は代表シナリオの結果で、全制作データの保証ではありません。

| 検証 | 4.5.9 | 5.2.2 |
|---|---|---|
| 既存Background統合テスト（T01〜T35のBackground対象） | PASS | PASS |
| 凸・凹L字・トーラス貫通穴・境界点 | PASS | PASS |
| 非等方/負Scale・shear・Bounds Center | PASS | PASS |
| 元Mesh・Modifier無視・移動時キャッシュ再使用 | PASS | PASS |
| MeshとEmpty混在・EXCLUDE・独立複製 | PASS | PASS |
| 行Isolate切替・参照選択・選択から作成・保存読込 | PASS | PASS |
| 開いたMesh・退化面・自己交差・分離面の拒否 | PASS | PASS |
| 不正入力時の確定結果保持・方式制限 | PASS | PASS |
| 実UIでUndo/Redo（既存操作＋Mesh登録＋選択から作成） | PASS | PASS |
| 実UIでLive・連続移動デバウンス・無変更時再評価なし・Cancel復元 | PASS | PASS |
| 全Operatorの説明文字列検査 | PASS | PASS |
| 全ボタン個別ホバーの目視確認 | NOT RUN | NOT RUN |
| 狭幅・長い名称・警告・連続Evaluateの全組合せ目視試験 | NOT RUN | NOT RUN |

最終UI修正後、5.2.2のUndo/Redo再試験で行OperatorのRNA警告が解消したことを確認。
共有Meshデータのあらゆる編集経路、極端に薄い形状、巨大座標、複雑な自己接触の網羅試験はNOT RUN。

## 性能

測定は1回の参考値。候補はEmpty Object、Mesh Volumeはトーラス256/1024三角形。計算時間はUI待ちを含みません。
RSSはSceneを含むプロセスの累積ピークで、アドオンの増分ではありません。並行アプリ稼働の影響を含みます。
機械可読値は `tools/reference/zone_groups/results/1.1.0/` に保存しています。

| Blender | Objects | 三角形 (0=Empty Box) | 初回 ms | 移動 ms | 最大区間 ms | 形状構築 ms | Native最大 ms | peak RSS MiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 4.5.9 | 1000 | 0 | 11.13 | 19.34 | 9.24 | 0.00 | 0.00 | 219.42 |
| 4.5.9 | 1000 | 256 | 24.12 | 23.43 | 5.15 | 2.46 | 0.52 | 220.11 |
| 4.5.9 | 1000 | 1024 | 27.60 | 18.39 | 5.58 | 6.19 | 1.57 | 221.45 |
| 4.5.9 | 10000 | 0 | 84.56 | 85.46 | 5.40 | 0.00 | 0.00 | 436.03 |
| 4.5.9 | 10000 | 256 | 177.68 | 177.97 | 5.27 | 2.58 | 0.40 | 436.97 |
| 4.5.9 | 10000 | 1024 | 183.11 | 179.08 | 5.43 | 6.92 | 1.61 | 438.91 |
| 4.5.9 | 50000 | 0 | 507.60 | 505.19 | 9.99 | 0.00 | 0.00 | 1328.25 |
| 4.5.9 | 50000 | 256 | 1005.73 | 844.41 | 12.21 | 12.62 | 0.62 | 1328.25 |
| 4.5.9 | 50000 | 1024 | 849.30 | 892.96 | 27.73 | 21.13 | 3.95 | 1328.25 |
| 5.2.2 | 1000 | 0 | 4.08 | 3.06 | 4.07 | 0.00 | 0.00 | 262.02 |
| 5.2.2 | 1000 | 256 | 18.89 | 15.63 | 6.21 | 4.86 | 0.62 | 264.66 |
| 5.2.2 | 1000 | 1024 | 21.19 | 15.06 | 5.15 | 7.11 | 1.67 | 266.19 |
| 5.2.2 | 10000 | 0 | 95.55 | 39.56 | 13.08 | 0.00 | 0.00 | 489.45 |
| 5.2.2 | 10000 | 256 | 154.90 | 148.70 | 7.75 | 2.09 | 0.63 | 489.45 |
| 5.2.2 | 10000 | 1024 | 152.87 | 148.40 | 5.94 | 8.40 | 1.67 | 489.45 |
| 5.2.2 | 50000 | 0 | 218.55 | 228.05 | 32.97 | 0.00 | 0.00 | 1412.70 |
| 5.2.2 | 50000 | 256 | 638.06 | 551.05 | 33.69 | 6.20 | 0.44 | 1415.38 |
| 5.2.2 | 50000 | 1024 | 562.81 | 673.02 | 57.96 | 13.99 | 2.22 | 1415.38 |

5.2.2の1万Object実UIテストは13項目PASS、全工程約141秒。大量Render制限の適用等を含む最大処理区間98.41ms、監視handler最大2.25ms。100秒ではタイムアウトし、300秒の上限で完走しました。この計測は最終の行RNA警告修正とレコード分割前であり、最終版で同じ大型UI試験の再測定はNOT RUN。最新の軽量Mesh Live/CancelとUndo/Redo試験とは区別しています。

**5msは目標で上限保証ではありません。** 特に大量表示/色フラグ変更、Blender依存関係更新、BVH構築・overlap列挙は長い区間になり得ます。形状の高密度化・自己接触によって検証コストは増えます。Liveは単純なMeshから試し、大規模Sceneや複雑なMeshではOn Demandを推奨します。色変更の全件負荷の1.1.0専用再計測はNOT RUN（旧版の実測はprevious_1.0.1_results.md）。

最終再試験で4.5.9の余分なGeometry更新通知による再構築を検出し、Raw Mesh比較を分割実行して未変更ならBVHを保持するよう修正。修正後の両バージョンのMesh回帰・Live/CancelはPASS。上の負荷表はこのキャッシュ検証追加前の計測で、最終版の全負荷表の再計測はNOT RUN。
