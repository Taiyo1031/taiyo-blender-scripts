# Replace Selected with Active

## 概要
選択オブジェクトを、アクティブオブジェクトのコピーに置き換えるアドオンです。

v3.0.1では、作成したコピーを「アクティブオブジェクト側のコレクション」へ入れるか、「各ターゲット側のコレクション」へ入れるかを選べます。

## 基本情報
- 本体ファイル: `__init__.py`
- 表示場所: `View3D > Sidebar > Replace`
- バージョン: `3.0.1`
- 対応Blender目安: `4.2.0` 以降
- カテゴリ: `Object`

## 使う場面
- 仮モデルを本番モデルへまとめて置き換えたい
- 選択した配置だけを別オブジェクトに差し替えたい
- ターゲットごとのコレクション構造を保ったまま置き換えたい

## 最短手順
1. 置き換え先になるターゲットオブジェクトを選択します。
2. 最後にコピー元オブジェクトを選択してアクティブにします。
3. `Replace` パネルで削除、配置先コレクション、トランスフォーム引き継ぎを設定します。
4. `Replace Selected Objects` を押します。

## 主な設定
- `Delete Targets After Replace`: 置き換え先を削除するか
- `Delete Source After Replace`: コピー元も最後に削除するか
- `Placement Collection`: 作成コピーの追加先
- `Active Object's Collection`: コピー元と同じコレクションへ追加
- `Target Object's Collection`: 各ターゲットと同じコレクションへ追加
- `Location` / `Rotation` / `Scale`: ターゲットから引き継ぐトランスフォーム

## 結果
アクティブオブジェクトのコピーを、選択ターゲットの位置などに作成します。

## 注意点
- コピー元は最後に選択したアクティブオブジェクトです。
- 最低2個のオブジェクト選択が必要です。
- `Target Object's Collection` を選ぶと、ターゲットごとの所属コレクションへコピーを追加します。
- 大量置き換えの前に `.blend` を保存しておくと戻しやすいです。

## 詳細な使用書
- `Replace_Selected_with_Active_使用書.md`

## GitHub仕様書
- [Replace_Selected_with_Active_使用書.md](https://github.com/Taiyo1031/taiyo-blender-scripts/blob/main/_Taiyo_Blender_Extensions_Repo/replace_selected_with_active/Replace_Selected_with_Active_%E4%BD%BF%E7%94%A8%E6%9B%B8.md)
