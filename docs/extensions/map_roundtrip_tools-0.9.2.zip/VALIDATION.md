# Map Roundtrip 検証報告

対象version: Map Roundtrip Tools **0.9.2**（Replaceの性能実測は0.1.0。0.1.1はUI・ヒントを更新。0.3.0の実測は末尾。0.4.0はidの扱い、0.5.0はCollection階層の復元のみ追加） / Unreal Bridge Tools **2.3.3**（性能測定時は2.3.0） / Taiyo Extension Manager **1.0.17**

検証日: 2026-11-11（日本時間）。macOS arm64、Blender **4.5.9 LTS** / **5.2.2 LTS**。外部のHoudini／Unrealは実行対象外です。

## 結果

配置・FBXの統合回帰と実UIのESC復元は合格しました。**6万件での生成時間の線形性、および最大0.5秒のUI応答目標は未達です。** Mesh共有のリンク複製方式は維持しています。

## 性能（秒）

| 件数 | CSV Selected | CSV Collection | plan | 生成＋最終同期 | Archive | Replace全体 | 最長単一step |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 10,000 | 0.268 | 0.243 | 0.037 | 4.314 | 0.034 | 4.416 | 0.728 |
| 30,000 | 0.829 | 0.719 | 0.142 | 59.327 | 0.105 | 59.645 | 2.139 |
| 60,000 | 1.649 | 1.501 | 0.278 | 281.792 | 0.262 | 282.516 | 3.878 |

10万点・全4ゾーン（5個のCube）のnumpy判定: **0.01374秒**（点の取得・選択適用を除く）。planは6万行でも3秒未満です。CSV Selectedは同一シーンのCollectionより約10%遅く、厳密な「同等以上」の目標は未達です。既存UBT回帰の別シーンでは6万行2.731秒でした。

![実測グラフ](benchmark_4_5_9.png)

生成は1万→3万→6万で約4.31→59.33→281.79秒となり、線形ではありません。Archiveは約0.034→0.105→0.262秒で、二次関数的な増加は見られませんでした。生成値には最後の依存グラフ同期が含まれます。単一stepはgeneratorのyield間隔で、timer全体の上限を保証する値ではありません。最長stepが0.5秒を超えるため、大規模処理の応答目標は満たせません。

### 原因切り分けと対策

- 既定の新規Collectionはシーン未リンク状態で充填します。既存Collectionは変更せず再利用します。
- 同名Objectの自動連番探索を避ける名前集合・連番キャッシュを追加しました。
- 切り分け用の1万Object試験では、評価済みシーンでObject.newが約5.29秒、linkが約0.022秒でした。未リンクCollectionでもObject.new約13.06秒・link約0.025秒で、Collection未リンク化だけでは解消しませんでした。Object.newとlinkを別フェーズに分ける試験もObject.new約5.26秒で解消しませんでした。
- 既存Collectionへの処理件数調整は、時間予算内で最大8192ステップまで自動調整します。最終同期や単一FBXオペレーターは分割できません。
- 計測には複数Blenderの一部実行時間帯が重なっています。再現用スクリプトと生JSONを同梱し、絶対時間は参考値とします。非線形傾向は対策前後の両方で再現しました。

## 仕様書§9.2 受け入れ16項目

| # | 結果 | 確認内容・制約 |
|---:|---|---|
| 1 | 合格 | 回転・スケール付きCube、複数領域、重複時のZONE_A優先を確認。 |
| 2 | 合格 | Selectedの行数・12列・名前・ワールドTransformを確認。6万行出力も実行。 |
| 3 | 合格 | 正常終了時だけタグ付与。ESC・エラー・一時出力再試行では中途タグなし。 |
| 4 | 合格 | 選択ゼロのエラーとファイル未作成を確認。 |
| 5 | 合格 | Previewの旧／新件数と非変更を確認。6万行planも一致。 |
| 6 | 合格 | Archive除外・所属移動・タグ変更・位置回転スケール・Mesh共有を確認。 |
| 7 | 未検証 | TransformとMesh共有の自動比較は合格。人による画面の目視比較は未実施。 |
| 8 | 合格 | 同じゾーンの再実行で現在タグ総数が一定、過去配置が追加Archive。 |
| 9 | 合格 | 作成中・Archive中・タグ変更中のESC／例外を検証。所属・タグ・一時hide・選択を復元。実UIは2000件。 |
| 10 | 合格 | Delete後の現在タグ数・共有Meshを確認。batch_removeを使用。 |
| 11 | 合格 | 未解決名のスキップ・集計と先頭5件表示を実装。 |
| 12 | 合格 | 未知colnameのMap直下Collection作成を確認。 |
| 13 | 合格 | Blender製FBX代用でSKIP／UPDATE／Material再利用を確認。UPDATE途中の中断でも旧Mesh参照へ復元。 |
| 14 | 合格 | Per Objectの12ファイル、サニタイズ、既存パスの連番、Combined、選択・active維持を確認。 |
| 15 | 合格 | LINEAR既定とカラー属性を含むFBX往復を確認。Unreal内の見た目は未検証。 |
| 16 | 不合格 | 6万件のCSV・plan・生成・Archiveを計測。生成線形性と0.5秒目標は未達。全16操作の6万件実UI再実行は未実施。 |

## 要検証3件

1. **FBX importer**: 4.5.9・5.2.2とも`wm.fbx_import`。旧Python版へのfallbackは模擬的なAPI欠落で回帰検証しました。
2. **temp_override**: 採用。複数選択中に1個だけ出力したFBXを再取り込みし、Mesh Objectが1個だけになることを両バージョンで確認しました。
3. **link線形性**: link単体より評価済みシーンでのObject作成が支配的でした。新規Collectionの未リンク充填と時間予算調整を採用しましたが、生成の非線形性は残っています。

## 変更・追加ファイル

- UBT: `__init__.py`、`preset_utils.py`、`blender_manifest.toml`、`README.md`、`Unreal_Bridge_Tools_使用書.md`を更新。`constants.py`、`zones.py`を追加。
- MRT: `__init__.py`、`constants.py`、`props.py`、`presets.py`、`chunked.py`、`fbx_export.py`、`mesh_import.py`、`placement.py`、`ui.py`、`blender_manifest.toml`、`README.md`、本報告、ベンチJSON／PNG、`tools/bench_make_scene.py`を追加。
- リポジトリ: `tools/test_map_roundtrip_tools.py`、`tools/benchmark_map_roundtrip_tools.py`、`tools/ui_test_map_roundtrip_tools.py`を追加。Extension Managerの本体／manifest／README、ビルド対象、README一覧、AGENTS、配布ZIP／indexを更新。

## 既定値と公開範囲

仕様書§11を採用しました。追加の実装上の既定は、非有限数値を不正行としてスキップすること、特異なゾーン変換をエラーにすること、復元中の再中断を抑止することです。FBX既定値やCSV列は変更していません。

配布indexは既存27件にMRTを加えた**28件**です。Object Groupsの公開済み内容は保持し、今回のcommitでは変更しません。Manager 1.0.17は公開済みの別名を維持し、MRT検索語と説明を追加します。

## 0.1.1 / UBT 2.3.2のUI更新

SceneへのZone登録・既存Empty登録・解除・保存復元・日本語ホバーヒントは tools/test_unreal_bridge_zone_registry.py でBlender 4.5.9 / 5.2.2にて確認。標準FBX画面の実UIは tools/ui_test_map_roundtrip_native_fbx.py で、標準ExporterのID、PRESET対応、選択MeshとLinearカラー初期値、キャンセル時の非出力を確認しました。補助機能の個別FBX出力と配置・復元の既存回帰も合格しました。手順は[詳細使用書](WORKFLOW_JA.md)にまとめています。

## 0.2.0の担当整理

ゾーン管理・範囲内Mesh選択・ゾーンCSV出力をMRTへ移しました。UBT 2.3.3は2.2.20相当の元の機能です。本報告の旧UBT Selected/Zone UIの記述と性能表は過去版の記録です。現行手順はWORKFLOW_JA.mdを参照してください。新しい回帰はtools/test_map_roundtrip_tools.py、test_map_roundtrip_zones.py、test_map_roundtrip_zone_registry.py、test_map_roundtrip_zone_migration.pyで検証します。

0.2.0の選択CSVはBlender 4.5.9で6万件0.787秒、最大tick0.085秒でした。MRT単独のゾーン管理・CSV・配置・FBX、旧ゾーンのAdd/Subtract/登録状態、個別/全ゾーンのEmpty選択を4.5.9/5.2.2で回帰確認します。

## 0.3.0の追加（Add Selected Objects・ゾーン範囲CSV・Zones UI再構成）

検証日: 2026-11-12（日本時間）。macOS arm64（Apple M1 Pro）、Blender **4.5.9 LTS**のみ。Blender 5.x・Linux・Houdini・Unrealは未検証です。

### 実測（6万Object）

2mの格子に並べた60,025個のMesh（共有Mesh）のうち、左半分の29,890個を選択して`tools/benchmark_map_roundtrip_add_objects.py`で測定しました。`Merge Distance`は5 m。シーン生成は11.78秒です。

| 操作 | 全体（秒） | 最長tick（秒） | 結果 |
|---|---:|---:|---|
| Add Selected Objects | 3.50（`bpy.ops`呼び出し込みで4.95） | 0.335 | 29,890個を4,802個のEmptyへ。分離不能0 |
| Select Meshes In Zone（確認用） | 6.30 | - | ゾーンの中身が選択と**完全一致**（欠落0・余分0） |
| Export Zone CSV | 6.48 | 0.473 | 29,890行。選択は使わない |

- 「全体」はオペレーターの状態表示の値です。括弧内の差は`bpy.ops`呼び出しとUndo保存の時間です。最長tickはタイマー1回分の最大実行時間（目標0.5秒以内）です。
- 1つの箱にまとめた数は、格子と`Merge Distance`に依存します。実際のシーンでは変わります。
- 6万件のReplace（配置生成）の性能は0.1.0から変わっていません（上表）。

### 実測で見つけて直した不具合

- **座標が大きいと箱の端のMeshが範囲から落ちる**: Blenderは行列をfloat32で持ち、逆行列の平行移動項に誤差が出ます。座標約490で、29,890個中4,324個が欠落しました。箱の余白を座標の大きさに比例させて解消し、座標490・5,000・50,000の回帰テストを追加しました（余白を0にすると490でテストが失敗します）。
- **最後の検証が1つのtickに固まっていた**（最長2.8秒）: 箱と点の比較を分割してyieldし、最長tickを0.335秒にしました。

### 実UI（Blender 4.5.9、`--enable-event-simulate`）

6,000個のMeshのうち3,000個を選択して確認しました。いずれも合格です。

- 作成の途中でESCを物理イベントで送ると、作ったEmptyをすべて取り消す。選択とMeshは変わらず、`Cancelled`と表示される。
- 通常完了後、ゾーンの中身がちょうど選択したMeshと一致する。評価済み（描画用）のEmptyも取得できる。
- Undoで追加したEmptyが消え、Redoで戻る。Meshは変わらない。

3Dビューのスクリーンショットでサイドバーを確認し、Zonesパネルが最上部に出ること、折りたたみ、`Merge Distance`、`Export ZONE_A.csv`のボタン名、日本語のホバーヒントが出ることを確認しました。

### 制約・未検証

- 1つのObjectだけのEmptyは範囲が約2 mmで、3Dビューでは点にしか見えません（`Zone Empties`の一覧から選択できます）。
- `Add Selected Objects`は未選択Meshと原点がほぼ同じObject（約2e-5以内）を分離できず、Emptyを作らずに件数で知らせます。
- 既存のSubtract範囲の判定（`removed by Subtract`）は箱の数が多いと時間がかかり、その区間は分割されません。
- 本人の制作Scene、Blender 4.5.10・5.x、Linuxでの確認、全16操作の6万件実UI再実行は未実施です。

## 0.4.0の追加（CSVのid判定）

検証日: 2026-11-13（日本時間）。macOS arm64、Blender **4.5.9 LTS**のみ。Houdini・Unrealは未検証です。

- Export Zone CSVが各行の`id`をMeshの`ub_csv_id`へ保存し、Houdiniから戻すPlacement CSVで`id`を判定します（`-1`＝追加Mesh、不明なid＝使用しない、`ub_csv_id`が無いゾーン＝判定なし）。
- 回帰：`tools/test_map_roundtrip_csv_id.py`（10項目）、既存の`test_map_roundtrip_tools.py` `_zones.py` `_zone_csv.py` `_add_objects.py` `_ui_layout.py` `_zone_registry.py` `_zone_migration.py` `_addon_lifecycle.py`がすべて合格しました。
- 性能は測っていません。追加した処理は行ごとの整数比較と、書き出し時のプロパティ1つの書き込みだけです。6万件での実測は未実施です。
- 取り込みパネルの実画面表示は未確認です（UIレイアウトテストのみ）。

## 0.5.0の追加（colnameの階層パス）

検証日: 2026-11-13（日本時間）。macOS arm64、Blender **4.5.9 LTS**のみ。Houdini・Unrealは未検証です。

- Export Zone CSVの`colname`が、Mapからの階層パス（例 `Area1/Rocks`）になり、Replace Zoneが`Map`の下に無いCollectionを入れ子のまま作ります。名前だけの旧CSVは、従来どおり名前で探します。
- 回帰：`tools/test_map_roundtrip_colname_path.py`（7項目：Map基準／Map未指定／`/`を含む名前／解決（既存・新規・途中の階層・旧名・`//`・先頭がMapの名前）／階層の作成と配置／名前の衝突の警告／ESC・例外でのロールバック／書き出し→復元）に加え、既存の9本がすべて合格しました。
- 6万Objectの書き出し（`tools/benchmark_map_roundtrip_add_objects.py`）：全体6.5〜6.96秒、最長tick 0.477〜0.510秒（0.4.0までは6.48秒、0.473秒）。測定のたびにばらつくため、目標の0.5秒前後です。colnameの計算中は4096件ごとに制御を返します。
- 数千個のCollectionを持つシーンでの時間は、測っていません。
- Mapの外にあったCollectionは`Map`の下に新しく作られ、元の場所へは戻りません。名前が既に使われていると`.001`が付きます（警告あり）。

## 0.5.1の追加（使用書のみ）

コードの動作は0.5.0と同じです。「Houdiniで変えた内容の扱い」を使用書へ追記し、その動作（移動＝新しい値で作り直し、削除＝旧Objectだけ退避、`id=-1`＋`colname`の階層パス＝入れ子のCollectionへ配置、不明idは未使用）を`tools/test_map_roundtrip_colname_path.py`の項目として追加しました。Blender 4.5.9で合格しました。Houdini実機は未検証です。

## 0.6.0の追加（EmptyをMeshのCollectionへ）

検証日: 2026-11-13（日本時間）。macOS arm64、Blender **4.5.9 LTS**のみ。

- Add Selected Objectsで作るEmptyを、シーンのルートではなく、元のMeshがいるCollectionへ入れます。まとめたEmptyは多数決（同数はシーンで先のCollection）で、複数のCollectionにまたがった数を`mixed-collection empties N`として出します。
- 回帰：`tools/test_map_roundtrip_empty_collection.py`（各Collection・ネスト・ルート／多数決と報告／同数／複数所属・シーン外Collection／ESCでの取り消し）に加え、既存の10本が合格しました。実UI（`tools/ui_test_map_roundtrip_add_objects.py`：ESC取り消し・完了・Undo・Redo・描画）も合格しました。
- 6万Object（すべてシーンのルート）の測定：Add Selected Objects 4.75〜4.84秒、最長tick 0.326〜0.329秒（0.3.0の実測は4.95秒、0.335秒）。ゾーンの中身は選択と完全一致です。Collectionが多数あるシーンでの時間は測っていません。
- 読み取り専用（リンクされた）Collectionの実機での挙動は、未確認です。編集できないときの退避先をシーンの最上位にしてあります。

## 0.7.0の追加（差分更新・復元・エラー詳細・追加Meshの置き場・Helper）

検証日: 2026-11-13（日本時間）。macOS arm64（Apple M1 Pro）、Blender **4.5.9 LTS**のみ。Houdini・Unrealは未検証です。

- **差分更新**: Replace Zoneは`ub_csv_id`で元のObjectと対応づけ、変わっていないObjectには触りません。動いたObjectはその場で更新、削除されたObjectは`_Replaced_ZONE_A`へ元の階層（ミラーCollection）のまま退避、新しいObjectだけを作ります。`Delete`は廃止しました。
- **復元**: Restore Original Map / Re-apply Imported Mapで、最初のReplace Zoneの前と取り込み後を切り替えます。取り込み後のObjectの手動編集は保たれます。
- **追加Mesh**: `New Meshes To`で取り込み先を選び、`Placement CSV`の`colname`の階層をミラーCollectionとして再現します。`colname`が複数ある場合は警告します。
- **エラー詳細**: CSVの行・列・値・理由を出します。パネルに最初の5件、全件はTextエディターの`MRT Placement Report`に書きます。
- **Helper**: Library/FromHoudiniのObjectがMapでどう使われているか（使用数・Collection・ゾーン）を調べ、選択できます。
- 回帰（すべて合格）: `tools/test_map_roundtrip_restore.py`（差分・復元・再適用・2回目のReplace・ESC・選択/非表示の保持・Importパネル・CSVの問題・ファイル全体の問題）、`test_map_roundtrip_mesh_import_paths.py`、`test_map_roundtrip_helper.py`、`test_map_roundtrip_tools.py`（Replace・ロールバック）、`_csv_id.py`、`_colname_path.py`、`_zones.py` `_zone_csv.py` `_add_objects.py` `_empty_collection.py` `_ui_layout.py` `_zone_registry.py` `_zone_migration.py` `_addon_lifecycle.py`。実UI（`tools/ui_test_map_roundtrip_tools.py`）では、物理ESCによる作成中・更新中の取り消し、Replace、Restore、Re-applyが合格しました。

### 6万Objectの実測（`tools/benchmark_map_roundtrip_diff.py`）

60,025個のMesh（Add Selected Objectsでゾーン化→Export Zone CSV）を、Houdiniから次のように返した想定です。変更なし30,012個、動いた20,008個（うち半数は別Collectionへ）、削除10,005個、新規10,000個。

| 操作 | 全体（秒） | 最長の分割できない1ステップ（秒） |
|---|---:|---:|
| Preview Placement | 0.55 | 0.05 |
| Replace Zone | 11.2〜11.3 | 2.2〜2.3（最後の依存グラフ同期） |
| Restore Original Map | 3.3〜3.6 | 2.0〜2.2（同上） |
| Re-apply Imported Map | 3.3〜3.4 | 2.0（同上） |

- Replace Zoneの内訳: 新しいObjectの作成7.7秒、CSVの計画0.56秒、移動0.4秒、退避0.2秒、最後の同期2.3秒。
- 0.6.0までの全作り直しは、6万件で約282.5秒でした（0.1.0の実測）。同じ6万件でも、変更の少ない戻りなら大幅に短くなります。変更が6万件すべてなら、作成の非線形性は残ります。
- **最後の同期（約2秒）は分割できず**、UIの応答目標（0.5秒）は、この1回分だけ超えます。
- 開発中に、動かしたObjectの選択・非表示を戻すループが68秒（2万件）かかる問題を見つけました。Collectionへの`link`を`unlink`より先に行うと、Base（選択・非表示の状態）が失われないため、そのループを無くしました（`test_selection_and_hide_flags_survive`で確認）。
- 未測定: 数千個のCollectionを持つシーン、Helperの走査時間、Blender 5.x、Linux。

## 0.7.1の追加（New Meshes ToがLibraryの外のとき）

- 実シーン（約6.6万Object、ゾーン`ZONE_1A`の旧3,258個、戻りCSV 647行）のコピーで再現しました。`New Meshes To`が`Library`の外（`NewOBJs`）だと、Import New Meshesは8個を取り込めるのに、Previewは`added 0, skipped 8 (not in Library)`でした。修正後は`added 8`、エラー0件、Replace Zoneは約1.7秒でした（Blender 4.5.9, M1 Pro）。
- 回帰: `tools/test_map_roundtrip_mesh_import_paths.py`（外にある取り込み先が探され、Mapの中の取り込み先は無視される）。
- Helperの照合は、Mapの各Objectごとに全Library Objectを調べていたため、`Library Mesh数 × Map Object数`の時間がかかっていました。Meshデータの集合で調べるよう直しました。実シーンでのHelper走査時間は未測定です。

## 0.7.2の追加（Houdini FBXの変換を焼き込む）

- 実シーンのコピーで再現しました。0.7.1では、新しいMesh 8個（`UNI`系6個と`Comb`系2個）が、CSVの位置に置かれませんでした。FBXのObjectは回転X 90度・スケール0.01で、Meshデータは元の座標（cm・Y-up）のままだったためです。置いたObjectはスケール1・回転0なので、向きが違い、100倍の大きさになり、`Comb`系は約2,000離れた場所に出ました。
- 修正後は、取り込み時にObjectの変換をMeshデータへ焼き込みます。`Gasyou_522_F_560`の寸法は、Library側の同種Meshと同じ向き・m単位（0.16×4.7×2.24）になり、置いたObjectの中心はCSVの位置（-21.56, -10.46, 8.89）と一致しました。`Comb`系もほかの部材と同じ範囲（約 -20.5, -9.2, 6〜7）に入りました（Blender 4.5.9）。
- 回帰: `tools/test_map_roundtrip_mesh_import_paths.py`（回転・スケール付きのObjectを模擬して、頂点の世界座標が保たれ、Objectの変換が単位になる）。
- 未確認: スケールが負（ミラー）のObject、同じMeshデータを違う変換で共有するFBX、Unrealなど他ツールのFBX。
- **実画面の確認**（Blender 4.5.9のGUI、実シーンのコピー、`--enable-event-simulate`）: Import New Meshes（8個）→ Preview（`added 8`、エラー0）→ Replace Zone中に物理ESC（8個を巻き戻し、ゾーンのObject 3,258個が開始時と完全に一致）→ Replace Zone → Restore Original Map（開始時と完全に一致）→ Re-apply Imported Map（新しい8個が戻る）→ Ctrl+Z（Replace前と完全に一致、アーカイブも消える）→ Ctrl+Shift+Z（Replace後に戻る）。いずれも成功しました。
- 実画面の確認で見つけた不具合: Ctrl+Zの後、退避したObject 3,155個の`ub_zone`などが戻りませんでした。Objectのカスタムプロパティだけの変更はUndoに記録されないためです。書き込みのたびに`update_tag()`を呼び、Replace・Restore・Importが1回ずつUndoできるようにしました。6万件の実測では、Replace 約13.8秒（0.7.0は約11.2秒）、Restore 約3.9秒（約3.4秒）で、最長の分割できない1ステップは約2.9秒でした。`update_tag`の分は少し遅くなっています。
- 実画面の確認で見つけたUIの問題: Restore Original Mapが、長い警告リストの下にあり、スクロールしないと見えませんでした。ボタンを警告リストの上へ移しました。
- 実GUIで、取り込みは約3〜22秒（FBX読み込み中の最長1ステップ 2.4〜17.9秒）でした。FBXの読み込み自体は分割できません。

## 0.8.0の追加（FBX変換のチェックボックス・Archive To・Rename Zone・Empty削除・Previewの案内）

- **実画面の確認**（Blender 4.5.9のGUI、実シーンのコピー、`--enable-event-simulate`）: `Convert Houdini FBX to Blender size`は既定OFF（OFFならObjectの回転90度・スケール0.01のまま取り込み、ONなら8個すべてに焼き込み）。`Archive To`に指定したCollectionの中に`_Replaced_ZONE_1A`が作られ、View Layerから除外されたまま。Replace → Ctrl+Z（開始時と完全に一致）→ Ctrl+Shift+Z → Rename Zone（`ZONE_1A`→`ZONE_1B`: ゾーンのObject 647個、退避したObject 2,595個、Empty、登録簿、`_Replaced_ZONE_1B`）→ Ctrl+Z（名前・`ub_zone`・`ub_archived_from`がすべて元どおり）。いずれも成功。
- Rename Zoneは、6万6千Objectのシーンで、確認0.04秒＋付け替え0.08秒でした。
- パネルにも、✎（Rename Zone）、`Archive To`、チェックボックス、集約された警告（以前は13件、今回は8件）が表示されることを画面で確認しました。
- 回帰: `tools/test_map_roundtrip_zone_rename.py` `_archive_dest.py` `_preview_hints.py` `_mesh_import_paths.py`（OFF/ON）`_zone_registry.py`（Empty削除）。
- LM Studioの使用: Previewの案内3点（`placement.py`）は1回目で合格しました（ただし重複名の警告に最初のObject名が抜けていたのと、新しいMeshの案内が二重に出る場合があったため、手で直しました）。Rename Zone（`zone_rename.py`）は5回の試行で合格せず、Objectの数え方と余分な未使用変数・空行を手で直しました。
- 未確認: 他の`.blend`で`Archive To`に既存の`_Replaced_*`がある場合の移動、複数シーンにまたがるゾーン名の変更、Blender 5.x、Linux、Houdini/Unrealでの実行。

## 0.8.1の追加（`id`が-1の行の数の表示）

- 実シーンのコピーで確認しました。Import New Meshesの前のPreviewは、`id`が-1の行が8行あるのに`New meshes (id -1): 0`でした（置けるMeshの数だけを数えていたため）。修正後は`0 of 8 rows`と、赤字の案内が出ます（Blender 4.5.9の画面）。取り込み後は`8 of 8 rows`です。
- 回帰: `tools/test_map_roundtrip_preview_hints.py`（3行のうち1行だけMeshがLibraryにあるとき`1 of 3`）。
- **見つけた動き（0.9.1で修正。`moved 139`の原因は、下の推測と違い、回転の比較の不具合でした）**（実シーンのコピー、Blender 4.5.9）:
  - Replace Zoneの後で、もう一度Previewすると`unchanged 500, moved 139, retired 8, added 8`になります。`retired 8`は、前のReplaceで追加した新しい8個です。`id`が-1の行は毎回新しいObjectを作るため、Replaceを繰り返すと、前に追加したObjectが退避され、同じ数が作り直されます。
  - `moved 139`は、`UNI`のように、他で既に使われている名前のCollectionが`UNI.001`として作られたため、`colname`の階層と名前が合わず、毎回「移動した」と判定されたものと考えられます（原因の特定は未確認）。

## 0.9.0の追加（`use`列、CSVに行が無い`id`は残す）

- 仕様: 戻りCSVの`use`列が`0`の行の`id`のObjectだけを`_Replaced_<Zone>`へ退避します。行が無い`id`のObjectは動かしません。`use`が`1`・空欄・列なしは使う行です。`use`が`0`の行は何も置かず、警告もありません。
- 回帰（Blender 4.5.9、すべて合格）: `tools/test_map_roundtrip_*.py` 17本と`test_mrt_zone_from_objects.py`、`test_unreal_bridge_tools.py`。既存テストのうち、行を消して退避を確認していた6本（`_restore` `_tools` `_csv_id` `_colname_path` `_archive_dest` `_preview_hints`）は、`use = 0`の行で退避する形に直しました。`test_map_roundtrip_preview_hints.py`に`use`の新しい検証を5件足しました（0だけ退避・行なしは残す／0の行は警告なし／`bad_use`と空欄／同じ`id`で0と1の競合／`use`列なしで退避なし）。
- 実UI（`tools/ui_test_map_roundtrip_tools.py`、`use = 0`の行で1/4を退避）は合格しました。
- 6万件（`tools/benchmark_map_roundtrip_diff.py`、M1 Pro）: Preview 0.63秒、Replace 11.9秒（最大の無中断ステップ2.4秒）、Restore 3.8秒、Re-apply 3.5秒。0.8.1（Replace 約13.8秒）と同等です。
- 注意（0.9.1で解消）: 行が無い`id`を退避しなくなったため、同じCSVで繰り返すと`id`が-1のObjectが増えました。
- 未確認: 実シーン（Houdiniから戻した`use`列つきCSV）、Blender 5.x、Linux、Houdini/Unrealでの実行。

## 0.9.1の追加（繰り返しReplaceの不具合3件）

- 実シーンのコピー（Blender 4.5.9）: Import New Meshes → Replace → もう一度Previewで、修正前は`moved 139`・`added 8`（0.8.1で見つけた2件）でしたが、修正後は`moved 0`・`create 0`・`retired 0`です。Replaceをもう一度行っても、Objectは増えず、変わりません。
- 原因: ①`id`が-1の行は毎回新しいObjectを作る作りでした。②`UNI`が他で使われているため`UNI.001`で作ったCollectionを、`colname`の`UNI`では見つけられませんでした。③`moved 139`は、**①②ではなく**、回転の比較の不具合でした。同じ回転でも、四元数が`q`と`-q`の違いで、回転の差が2π（360度）と出ていました（実シーンの139個、`UNI.001`は関係ありませんでした）。同じ原因で、最初のPreviewの`moved 552`のうち7個は、実際には動いていませんでした（修正後は545）。
- 回帰: `tools/test_map_roundtrip_repeat_replace.py`（回転の符号・繰り返しReplace・Restore/Re-apply・`UNI.001`・手で名前を変えた場合）。既存の17本、`test_mrt_zone_from_objects.py`、`test_unreal_bridge_tools.py`、実UIは合格しました。
- 前回のReplaceで作ったObjectは、`ub_run`の`before`が`null`で`ub_csv_id`が無いものとして見分けます。書き出し直して`ub_csv_id`が付いたObjectは、通常の`id`の対応です。
- 未確認: Houdiniから実際に戻した`use`列つきCSV、Blender 5.x、Linux、Unreal。

## 0.9.2の追加（退避したObjectを新しいCSVで戻す）

- 実シーンのコピー（`BO_StPrlg_BaseMap_V16`のZONE_1、Blender 5.2.2。保存先は元のファイルとは別のコピー）: 前のReplaceで1026個を退避した状態で、`use`が1に変わった戻りCSV（4910行）をPreviewすると、修正前は`unknown id 428`（すべて屋根瓦）で`moved 0`、修正後は`moved 428 (brought back from the archive 428)`・`unknown id 0`でした。Replaceは約2.7秒、続けてPreviewすると`moved 0`です。Restore Original Mapで3258個、Re-apply Imported Mapで2672個になり、もう一度Previewしても`moved 0`・`create 0`でした。
- 修正前は、Restore Original Mapの後は、Replace Zone・Previewとも`showing the original map`で止まり、新しいCSVを適用する手段がありませんでした。
- 重複の原因: Restore / Re-applyは、切り替えたObjectの`ub_run`へ`after`を書きます。前回のReplaceで作ったObjectを見分ける判定が`after`の無いものだけを対象にしていたため、切り替えの後は`id`が-1の行を毎回新しく作っていました。`before`がnullであれば、`after`があっても前回作ったObjectとして扱います。
- 回帰: `tools/test_map_roundtrip_repeat_replace.py`（退避したObjectの復活・同じCSVの`use`が0だけなら何もしない・Libraryに無いMeshの行は退避のまま・切り替え後の重複なし）。既存の`restore`・`csv_id`・`colname_path`・`archive_dest`・`preview_hints`・`mesh_import_paths`・`ui_layout`・`tools`・`zone_csv`・`zone_rename`は合格しました（Blender 4.5.9）。
- 未確認: Blender 5.1.2（5.2.2と4.5.9で確認）、実UIのESC、Houdiniの再実行。
