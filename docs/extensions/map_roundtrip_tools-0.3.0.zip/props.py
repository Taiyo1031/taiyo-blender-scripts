import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from .zones import MRT_ZoneEntry, zone_items
from .constants import BUILTIN_PRESET
from .presets import preset_items, apply_selected


def enum(items):
    return [(s, s.replace('_', ' ').title(), '') for s in items]


class MRT_Props(bpy.types.PropertyGroup):
    zones: CollectionProperty(type=MRT_ZoneEntry)
    zone_prefix: StringProperty(name='Zone Prefix', default='ZONE_', description='従来Cube Emptyの自動検出用接頭辞。UI登録したEmptyは接頭辞に依存しません')
    zone_choice: EnumProperty(name='Zone', items=zone_items, description='操作するゾーン。All Zonesなら全ゾーンをまとめて選択します')
    zone_result: StringProperty(options={'SKIP_SAVE'})
    zone_scope: EnumProperty(name='Mesh Candidates', items=[('MAP','Map Collection','Mapと子CollectionのMesh'),('SCENE','All Scene Meshes','現在のSceneのMesh')], default='MAP')
    zone_csv_dir: StringProperty(name='CSV Output Folder', subtype='DIR_PATH', default='//houdini_io/out', description='選択Meshをゾーン名.csvへ書き出します。ub_zoneも現在のZone名になります')
    merge_distance: FloatProperty(name='Merge Distance', default=1.0, min=0.0, soft_max=100.0, subtype='DISTANCE', description='Add Selected Objectsで、この距離以内の原点を1つのEmptyにまとめます。0なら選択Objectごとに1つ作ります。未選択のObjectが範囲に入る場合は自動で分割します')
    zone_empty_filter: StringProperty(name='Search', options={'TEXTEDIT_UPDATE', 'SKIP_SAVE'}, description='Zone Emptiesの一覧を名前で絞り込みます。大小文字は区別しません。数が多いときは先頭50件だけ表示します')
    exchange_dir: StringProperty(description='BlenderとHoudiniの受け渡しフォルダーを記録する参考欄です。変更してもCSV/FBXの保存先は自動変更されず、フォルダー作成や監視もしません', name='Exchange Folder', subtype='DIR_PATH', default='//houdini_io')
    zone_name: StringProperty(description='標準FBX画面の初期ファイル名と補助機能のCombined FBX名に使います。範囲選択のZoneやCSVのub_zoneタグを変更する欄ではありません', name='FBX Name', default='ZONE_A')
    fbx_preset: EnumProperty(description='FBX Advanced設定のプリセット。組み込みUnreal SMは変更・削除できません', name='Preset', items=preset_items, update=apply_selected)
    show_batch_export: BoolProperty(name='Advanced / Batch Export', default=False, description='Objectごとの個別FBX一括出力用の補助設定を開きます。通常はExport FBX (Blender)を使います')
    fbx_files: EnumProperty(description='Per Objectは選択Meshごとに1ファイル、Combinedは選択Meshを1ファイルへ出力します', name='Files', items=[('PER_OBJECT', 'Per Object', ''), ('COMBINED', 'Combined', '')], default='PER_OBJECT')
    fbx_out_dir: StringProperty(description='実際にFBXを書き出すフォルダー。存在しない場合は出力時に作成します', name='Output Folder', subtype='DIR_PATH', default='//houdini_io/out/fbx')
    fbx_scale: FloatProperty(description='FBX出力全体の倍率。既定1.0', name='Scale', default=1, min=.000001)
    fbx_apply_scalings: EnumProperty(description='FBXでの単位倍率とObject倍率の扱い。既定FBX Units Scale', name='Apply Scalings', items=[('FBX_SCALE_NONE', 'All Local', ''), ('FBX_SCALE_UNITS', 'FBX Units Scale', ''), ('FBX_SCALE_CUSTOM', 'FBX Custom Scale', ''), ('FBX_SCALE_ALL', 'FBX All', '')], default='FBX_SCALE_UNITS')
    fbx_axis_forward: EnumProperty(description='FBX出力先の前方向。既定-Z。Upと同じ軸は指定できません', name='Forward', items=enum(['X', 'Y', 'Z', '-X', '-Y', '-Z']), default='-Z')
    fbx_axis_up: EnumProperty(description='FBX出力先の上方向。既定Y。Blender内の配置CSVはZ-upのままです', name='Up', items=enum(['X', 'Y', 'Z', '-X', '-Y', '-Z']), default='Y')
    fbx_apply_modifiers: BoolProperty(description='FBXへモディファイアー適用後のMeshを書き出します', name='Apply Modifiers', default=True)
    fbx_smoothing: EnumProperty(description='FBXのスムージング情報の出力方式。既定Face', name='Smoothing', items=enum(['OFF', 'FACE', 'EDGE']), default='FACE')
    fbx_vertex_colors: EnumProperty(description='頂点カラーの出力方式。既定Linear。Noneはカラーを出力しません', name='Vertex Colors', items=enum(['NONE', 'SRGB', 'LINEAR']), default='LINEAR')
    fbx_triangulate: BoolProperty(description='FBX出力時に面を三角形へ分割します', name='Triangulate', default=False)
    fbx_tangent: BoolProperty(description='FBXへ接線情報を書き出します', name='Tangent Space', default=False)
    fbx_apply_transform: BoolProperty(description='FBXの軸変換をMeshへ焼き込みます。既定OFF', name='Apply Transform', default=False)
    library_coll: PointerProperty(description='配置の元となるMesh Objectの保管場所。例ForExport_Dirty_1。子Collectionも名前検索します', name='Library', type=bpy.types.Collection)
    map_coll: PointerProperty(description='CSVから再生成した配置を入れるCollection。例Laid_MAP_1。Libraryとは役割が異なります', name='Map', type=bpy.types.Collection)
    new_mesh_coll_name: StringProperty(description='追加FBXのMeshをLibraryのこの子Collectionへ格納します。既定FromHoudini', name='New Meshes To', default='FromHoudini')
    return_dir: StringProperty(description='Houdiniから返すファイルの参考フォルダー。Placement CSVやMesh FBXは下で個別指定してください。自動読込はしません', name='Return Folder', subtype='DIR_PATH', default='//houdini_io/in')
    placement_csv: StringProperty(description='実際に読み込む配置CSV。ヘッダー付き12列。Zone空欄時はこのファイル名が置換ゾーンになります', name='Placement CSV', subtype='FILE_PATH')
    mesh_fbx: StringProperty(description='追加のLibrary Meshを含むFBX。追加Meshがなければ指定・取込は不要です', name='Mesh FBX', subtype='FILE_PATH')
    name_mode: EnumProperty(description='Library Mesh名の照合方式。CSV書き出しとLibrary照合に使用します。読込は完全一致を優先し、次に正規化した名前で検索します', name='Name Normalize', items=[('keep_raw', 'Keep Raw', ''), ('numeric_suffix', 'Remove Numeric Suffix (.001+)', ''), ('trim_after_dot', 'Trim After Dot', '')], default='numeric_suffix')
    if_exists: EnumProperty(description='Skipは既存同名Meshを保持。UpdateはそのMeshを共有する全Objectを新Meshへ差し替えます', name='If Exists', items=enum(['SKIP', 'UPDATE']), default='SKIP')
    zone_override: StringProperty(description='置換対象ub_zoneの名前。空欄ならPlacement CSV名。書き出し時のCSV名と一致させてください', name='Zone')
    old_mode: EnumProperty(description='Archiveは旧Objectを退避し保持します。Deleteは旧Objectを削除します', name='Old Objects', items=enum(['ARCHIVE', 'DELETE']), default='ARCHIVE')
    dry_run: BoolProperty(description='ONはPreviewだけで配置を変えません。確認後にOFFにするとReplaceを実行します。作業前に.blendを保存してください', name='Dry Run', default=True)
    plan_ready: BoolProperty(default=False, options={'SKIP_SAVE'})
    plan_archive: IntProperty(default=0, options={'SKIP_SAVE'})
    plan_create: IntProperty(default=0, options={'SKIP_SAVE'})
    plan_invalid: IntProperty(default=0, options={'SKIP_SAVE'})
    plan_missing: IntProperty(default=0, options={'SKIP_SAVE'})
    plan_missing_rows: IntProperty(default=0, options={'SKIP_SAVE'})
    plan_collections: IntProperty(default=0, options={'SKIP_SAVE'})
    plan_zone: StringProperty(options={'SKIP_SAVE'})
    plan_names: StringProperty(options={'SKIP_SAVE'})
    plan_new_meshes_imported: IntProperty(default=0, options={'SKIP_SAVE'})
    last_export: StringProperty(default='none', options={'SKIP_SAVE'})
    running: BoolProperty(default=False, options={'SKIP_SAVE'})
    cancel_requested: BoolProperty(default=False, options={'SKIP_SAVE'})
    progress: FloatProperty(default=0, options={'SKIP_SAVE'})
    status: StringProperty(options={'SKIP_SAVE'})
    max_tick: FloatProperty(default=0, options={'SKIP_SAVE'})
