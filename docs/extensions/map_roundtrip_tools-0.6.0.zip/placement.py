"""Plan first; create linked objects; commit archive/delete last."""
import csv
import math
import os
import re
from dataclasses import dataclass, field
import bpy
from .constants import ZONE_KEY, ARCHIVED_KEY, COLNAME_SEPARATOR, CSV_COLUMNS, CSV_ID_KEY, NEW_MESH_ID
from .chunked import ChunkedOperator


def normalize(name, mode):
    if mode == 'numeric_suffix':
        return re.sub(r'\.\d{3,}$', '', name)
    if mode == 'trim_after_dot':
        return name.split('.', 1)[0]
    return name


class NameAllocator:
    """Avoid Blender's quadratic repeated auto-suffix search for shared names."""
    def __init__(self, names):
        self.names = names
        self.next_suffix = {}

    def take(self, name):
        if name not in self.names:
            self.names.add(name)
            return name
        base = re.sub(r'\.\d{3,}$', '', name)
        # Leave room for Blender's numeric suffix within the 63-byte ID limit.
        base = base.encode('utf-8')[:59].decode('utf-8', errors='ignore')
        index = self.next_suffix.get(base, 1)
        candidate = f'{base}.{index:03d}'
        while candidate in self.names:
            index += 1
            candidate = f'{base}.{index:03d}'
        self.next_suffix[base] = index + 1
        self.names.add(candidate)
        return candidate


def walk_collections(root):
    pending = [root]
    seen = set()
    while pending:
        c = pending.pop()
        if c in seen:
            continue
        seen.add(c)
        yield c
        pending.extend(reversed(tuple(c.children)))


def build_parent_index(map_coll):
    """First parent of every collection (parents inside the map tree win) and the set of scene root collections."""
    parents = {}
    if map_coll is not None:
        for c in walk_collections(map_coll):
            for child in c.children:
                parents.setdefault(child, c)
    roots = {scene.collection for scene in bpy.data.scenes}
    for c in (*bpy.data.collections, *roots):
        for child in c.children:
            parents.setdefault(child, c)
    return parents, roots


def collection_colname(collection, map_coll, parents, roots):
    """The CSV colname of a collection: its path below the Map collection (or below the scene root).

    The Map collection and scene roots give an empty name. A name that contains the separator cannot be written as a
    path without becoming ambiguous, so the plain collection name is used instead.
    """
    names, node, seen = [], collection, set()
    while node is not None and node != map_coll and node not in roots and node not in seen:
        seen.add(node)
        names.append(node.name)
        node = parents.get(node)
    if any(COLNAME_SEPARATOR in name for name in names):
        return collection.name
    return COLNAME_SEPARATOR.join(reversed(names))


def map_collection_paths(map_coll):
    """{(name, ...): collection} for every collection below the Map collection."""
    index, stack, seen = {}, [(map_coll, ())], set()
    while stack:
        c, path = stack.pop()
        if c in seen:
            continue
        seen.add(c)
        if path:
            index.setdefault(path, c)
        stack.extend((child, path + (child.name,)) for child in reversed(tuple(c.children)))
    return index


def resolve_colname(plan, map_coll, colname):
    """Find the collection for a CSV colname, or record the collections that have to be created.

    1. A collection of that exact name in the Map tree (older CSVs; also the Map collection itself).
    2. Otherwise colname is a path below Map. Missing collections are planned, parents before children.
    """
    if colname in plan.collections or colname in plan.colname_new:
        return
    parts = tuple(colname.split(COLNAME_SEPARATOR))
    if any(not part for part in parts):
        parts = (colname,)  # not a clean path: treat it as one literal name
    if len(parts) > 1 and parts[0] == map_coll.name:
        parts = parts[1:]  # written without a Map collection set: 'Map/Area1' means Area1 below Map
    existing = next((k for k in range(len(parts), 0, -1) if parts[:k] in plan.path_index), 0)
    if existing == len(parts):
        plan.collections[colname] = plan.path_index[parts]
        return
    plan.colname_new[colname] = parts
    for k in range(existing + 1, len(parts) + 1):
        plan.new_collections.add(parts[:k])
        if parts[k - 1] in bpy.data.collections:
            plan.name_conflicts.add(COLNAME_SEPARATOR.join(parts[:k]))


def effective_zone(p):
    return p.zone_override.strip() or os.path.splitext(os.path.basename(bpy.path.abspath(p.placement_csv)))[0]


@dataclass
class Plan:
    zone: str
    rows: list = field(default_factory=list)
    old: list = field(default_factory=list)
    collections: dict = field(default_factory=dict)
    new_collections: set = field(default_factory=set)  # tuples of names, relative to the Map collection
    colname_new: dict = field(default_factory=dict)  # colname -> tuple of names that has to be created
    path_index: dict = field(default_factory=dict)  # tuple of names -> existing collection below Map
    name_conflicts: set = field(default_factory=set)  # new paths whose name is already used elsewhere
    unmatched: set = field(default_factory=set)
    missing_rows: int = 0
    invalid: int = 0
    duplicates: int = 0
    memberships: list = field(default_factory=list)
    object_names: set = field(default_factory=set)
    added: int = 0            # rows with id -1 whose Library mesh was found
    unknown_id_rows: int = 0  # rows skipped because their id is unknown
    id_check: bool = False    # whether ids were checked (the zone has ub_csv_id)


def build_plan(p, progress=lambda *args: None):
    if p.library_coll is None:
        raise ValueError('Library collection is not set.')
    if p.map_coll is None:
        raise ValueError('Map collection is not set.')
    path = bpy.path.abspath(p.placement_csv)
    if not p.placement_csv or not os.path.isfile(path):
        raise ValueError('Placement CSV does not exist.')
    zone = effective_zone(p)
    if not zone:
        raise ValueError('Zone name is empty.')
    plan = Plan(zone)
    exact, norm, seen = {}, {}, set()
    for c in walk_collections(p.library_coll):
        for i, ob in enumerate(c.objects):
            if ob not in seen and ob.type == 'MESH':
                seen.add(ob)
                exact[ob.name] = ob.data
                name = normalize(ob.name, p.name_mode)
                if name in norm:
                    plan.duplicates += 1
                else:
                    norm[name] = ob.data
            if i % 512 == 0:
                yield
        yield
    for c in walk_collections(p.map_coll):
        plan.collections.setdefault(c.name, c)
        yield
    plan.path_index = map_collection_paths(p.map_coll)
    # Old objects are needed before the rows so ids can be checked.
    for i, ob in enumerate(bpy.data.objects):
        plan.object_names.add(ob.name)
        if ob.get(ZONE_KEY) == zone:
            plan.old.append(ob)
        if i % 1024 == 0:
            yield
    # ids the zone's objects had at their last CSV export.
    known_ids = set()
    for ob in plan.old:
        value = ob.get(CSV_ID_KEY)
        if isinstance(value, (int, float)) and not isinstance(value, bool) and float(value).is_integer():
            known_ids.add(int(value))
    plan.id_check = bool(known_ids)
    with open(path, newline='', encoding='utf-8-sig') as stream:
        reader = csv.reader(stream)
        header = next(reader, [])
        columns = {name: i for i, name in enumerate(header)}
        missing = set(CSV_COLUMNS) - columns.keys()
        if missing:
            raise ValueError('Missing CSV columns: ' + ', '.join(sorted(missing)))
        indices = [columns[n] for n in CSV_COLUMNS[1:10]]
        for number, row in enumerate(reader, 1):
            try:
                value = float(row[columns['id']])
                if not value.is_integer():
                    raise ValueError('Non-integer id')
                csv_id = int(value)
                values = tuple(float(row[i]) for i in indices)
                if not all(math.isfinite(v) for v in values):
                    raise ValueError('Non-finite transform')
                name, colname = row[columns['objname']], row[columns['colname']]
            except (ValueError, IndexError):
                plan.invalid += 1
            else:
                if plan.id_check and csv_id != NEW_MESH_ID and csv_id not in known_ids:
                    plan.unknown_id_rows += 1  # not used, and not counted as a missing Library mesh
                else:
                    mesh = exact.get(name)
                    if mesh is None:
                        mesh = norm.get(normalize(name, p.name_mode))
                    if mesh is None:
                        plan.unmatched.add(name)
                        plan.missing_rows += 1
                    else:
                        tx, ty, tz, rx, ry, rz, sx, sy, sz = values
                        factor = math.pi / 180.0
                        plan.rows.append((mesh, name, (tx, ty, tz), (rx * factor, ry * factor, rz * factor), (sx, sy, sz), colname))
                        if csv_id == NEW_MESH_ID:
                            plan.added += 1
                        if colname:
                            resolve_colname(plan, p.map_coll, colname)
            if number % 256 == 0:
                progress('Planning CSV', number, number)
                yield
    # Snapshot membership by collection, never per-object users_collection.
    if not p.map_coll.is_editable:
        raise ValueError('Map collection is not editable.')
    for ob in plan.old:
        if not ob.is_editable:
            raise ValueError(f'Old object is not editable: {ob.name}')
    old_set = set(plan.old)
    roots = {scene.collection for scene in bpy.data.scenes}
    for c in (*bpy.data.collections, *roots):
        members = []
        for i, ob in enumerate(c.objects):
            if ob in old_set:
                members.append(ob)
            if i % 1024 == 0:
                yield
        if members:
            if not c.is_editable:
                raise ValueError(f'Old collection is not editable: {c.name}')
            plan.memberships.append((c, members))
        yield
    return plan


def publish_plan(p, plan):
    p.plan_archive = len(plan.old)
    p.plan_create = len(plan.rows)
    p.plan_invalid = plan.invalid
    p.plan_missing_rows = plan.missing_rows
    p.plan_missing = len(plan.unmatched)
    names = sorted(plan.unmatched)
    p.plan_names = ', '.join(names[:5]) + (f' …and {len(names)-5} more' if len(names) > 5 else '')
    p.plan_zone = plan.zone
    p.plan_collections = len(plan.new_collections)
    p.plan_added = plan.added
    p.plan_unknown_id = plan.unknown_id_rows
    p.plan_id_check = plan.id_check
    p.plan_ready = True


def find_layer(root, collection):
    pending = [root]
    while pending:
        layer = pending.pop()
        if layer.collection == collection:
            return layer
        pending.extend(layer.children)
    return None


class MRT_OT_ReplaceZone(ChunkedOperator, bpy.types.Operator):
    bl_description = 'Dry Run ONなら計画のみ確認。OFFなら同じub_zoneの旧配置を退避または削除して新配置を作ります'
    bl_idname = 'mrt.replace_zone'
    bl_label = 'Preview Placement / Replace Zone'

    def work(self, context):
        p = context.scene.mrt_props
        p.plan_ready = False
        plan = yield from build_plan(p, self.progress)
        publish_plan(p, plan)
        if plan.duplicates:
            self.report({'WARNING'}, f'{plan.duplicates} duplicate normalized Library names; first match used.')
        if plan.name_conflicts:
            shown = sorted(plan.name_conflicts)
            self.report({'WARNING'}, 'Collection names already used elsewhere; the new ones get a suffix: '
                        + ', '.join(shown[:5]) + (f' …and {len(shown) - 5} more' if len(shown) > 5 else ''))
        if p.dry_run:
            self.result = f'Preview {plan.zone}: {len(plan.rows)} instances, {len(plan.old)} old objects, {plan.invalid} invalid rows, new meshes {plan.added}, unknown id {plan.unknown_id_rows}'
            return
        created, collections, archived, unlinked, remapped_tags = [], [], [], [], []
        archive = None
        archive_created = False
        archive_layer = None
        prior_exclude = None
        committed = False
        old_mode = p.old_mode
        allocator = NameAllocator(plan.object_names)
        old_tags = {ob: (ARCHIVED_KEY in ob, ob.get(ARCHIVED_KEY)) for ob in plan.old}
        old_set = set(plan.old)
        old_states, hidden_objects = [], []
        original_active = context.view_layer.objects.active
        for i, ob in enumerate(context.view_layer.objects):
            hidden = ob.hide_get()
            if hidden:
                hidden_objects.append(ob)
            if ob in old_set:
                old_states.append((ob, hidden, ob.select_get()))
            if i % 512 == 0:
                yield
        try:
            made, attach = {}, []
            for path in sorted(plan.new_collections):  # a parent path sorts before its children
                c = bpy.data.collections.new(path[-1])
                collections.append(c)
                made[path] = c
                if path[:-1] in made:
                    made[path[:-1]].children.link(c)  # both new: link while detached to avoid view-layer resync
                else:
                    attach.append((plan.path_index[path[:-1]] if len(path) > 1 else p.map_coll, c))
                yield
            for colname, path in plan.colname_new.items():
                plan.collections[colname] = made[path]
            for i, (mesh, name, loc, rot, scale, colname) in enumerate(plan.rows):
                ob = bpy.data.objects.new(allocator.take(name), mesh)
                created.append(ob)
                ob.location = loc
                ob.rotation_mode = 'XYZ'
                ob.rotation_euler = rot
                ob.scale = scale
                ob[ZONE_KEY] = plan.zone
                c = plan.collections[colname] if colname else p.map_coll
                c.objects.link(ob)
                self.progress('Creating linked instances', i + 1, len(plan.rows))
                yield
            for parent, c in attach:
                parent.children.link(c)
                yield
            # A single explicit update, outside the creation loop.
            context.view_layer.update()
            if old_mode == 'ARCHIVE' and plan.old:
                archive_name = '_Replaced_' + plan.zone
                archive = context.scene.collection.children.get(archive_name)
                if archive is None:
                    archive = bpy.data.collections.new(archive_name)
                    archive_created = True
                    context.scene.collection.children.link(archive)
                archive_layer = find_layer(context.view_layer.layer_collection, archive)
                if archive_layer:
                    prior_exclude = archive_layer.exclude
                    archive_layer.exclude = True
                archive_members = set(archive.objects)
                for i, ob in enumerate(plan.old):
                    if ob not in archive_members:
                        archive.objects.link(ob)
                        archived.append(ob)
                    self.progress('Archiving', i + 1, len(plan.old))
                    yield
                for c, members in plan.memberships:
                    if c == archive:
                        continue
                    for ob in members:
                        c.objects.unlink(ob)
                        unlinked.append((c, ob))
                        yield
                for ob in plan.old:
                    remapped_tags.append(ob)
                    ob[ARCHIVED_KEY] = plan.zone
                    del ob[ZONE_KEY]
                    yield
            elif old_mode == 'DELETE' and plan.old:
                # Final irreversible operation. No cancellable step follows.
                bpy.data.batch_remove(ids=plan.old)
            committed = True
        except BaseException as exc:
            if not committed:
                # Cancellation is deferred while restoration is in progress.
                self.progress('Rolling back', 0, len(created) + len(unlinked))
                for c, ob in reversed(unlinked):
                    c.objects.link(ob)
                    yield
                for ob in remapped_tags:
                    ob[ZONE_KEY] = plan.zone
                    existed, value = old_tags[ob]
                    if existed:
                        ob[ARCHIVED_KEY] = value
                    elif ARCHIVED_KEY in ob:
                        del ob[ARCHIVED_KEY]
                    yield
                for ob in archived:
                    archive.objects.unlink(ob)
                    yield
                # Batches keep rollback responsive as well.
                for start in range(0, len(created), 512):
                    bpy.data.batch_remove(ids=created[start:start + 512])
                    yield
                if collections:
                    bpy.data.batch_remove(ids=collections)
                if archive_created:
                    bpy.data.collections.remove(archive)
                elif archive_layer is not None and prior_exclude is not None:
                    archive_layer.exclude = prior_exclude
                # Membership/exclude changes recreate Bases and may lose their
                # temporary hide and selection flags. All reads preceded writes.
                for ob, hidden, selected in old_states:
                    ob.hide_set(hidden)
                    ob.select_set(selected)
                    yield
                for ob in hidden_objects:
                    ob.hide_set(True)
                    yield
                context.view_layer.objects.active = original_active
                self._error = f'Rolled back {len(created)} objects. ' + (self._error or str(exc) or 'Operation failed.')
            raise
        self.result = (f'Replaced {plan.zone}: created {len(created)}, '
                       f'{"archived" if old_mode == "ARCHIVE" else "deleted"} {len(plan.old)}, '
                       f'skipped {plan.missing_rows} (not in Library), invalid rows {plan.invalid}, new meshes {plan.added}, unknown id {plan.unknown_id_rows}')
